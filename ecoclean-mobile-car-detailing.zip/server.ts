import "dotenv/config";
import express from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import {
  GoogleGenAI,
  Type,
  ThinkingLevel,
  type Content,
  type FunctionDeclaration,
} from "@google/genai";
import {
  BUSINESS_PROFILE,
  FAQ_ITEMS,
  OPERATIONAL_CHECKLIST,
  PAYMENT_METHODS,
  SERVICE_TIERS,
  TIME_WINDOWS,
  calculateEstimate,
  formatZar,
  type BookingRecord,
  type ServiceTierId,
  type VehicleCondition,
  type VehicleSize,
} from "./src/data/ecoclean.ts";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const MODEL_NAME = "gemini-4-hydrogen";

function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      "GEMINI_API_KEY is not configured. Please add your Gemini API key in Settings > Secrets."
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// In-memory booking store seeded with one realistic South African example
const bookings: BookingRecord[] = [
  {
    id: "EC-4812",
    customerName: "Thabo Mokoena",
    contact: "thabo.mokoena@example.co.za",
    location: "14 Oak Avenue, Bryanston, Johannesburg",
    vehicleDescription: "2024 Volkswagen Tiguan R-Line",
    vehicleSize: "suv",
    serviceTierId: "complete_eco",
    serviceTierName: "Complete Eco Detail",
    date: new Date().toISOString().slice(0, 10),
    timeWindow: "13:30",
    interiorAccessMethod: "Remote app unlock on technician arrival",
    paymentMethodPreference: "Mobile App Payment",
    estimatedDuration: "2 hrs 5 min",
    estimatedPrice: 1050,
    checklistStepCompleted: 2,
    status: "In Progress",
    createdAt: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
  },
];

function getAvailableSlotsForDate(dateStr: string): string[] {
  const takenOnDate = new Set(
    bookings.filter((b) => b.date === dateStr).map((b) => b.timeWindow)
  );
  return TIME_WINDOWS.filter((slot) => !takenOnDate.has(slot));
}

function generateBookingId(): string {
  const code = Math.floor(1000 + Math.random() * 9000);
  return `EC-${code}`;
}

function normalizeVehicleSize(raw: unknown): VehicleSize {
  const val = String(raw || "").toLowerCase();
  if (val === "suv") return "suv";
  if (val === "bakkie_mpv" || val === "truck_van" || val.includes("bakkie")) {
    return "bakkie_mpv";
  }
  return "sedan";
}

function createBookingRecord(input: {
  customerName: string;
  contact: string;
  location: string;
  vehicleDescription: string;
  vehicleSize: VehicleSize;
  serviceTierId: ServiceTierId;
  condition?: VehicleCondition;
  date: string;
  timeWindow: string;
  interiorAccessMethod?: string;
  paymentMethodPreference?: string;
}): BookingRecord {
  const normalizedSize = normalizeVehicleSize(input.vehicleSize);
  const estimate = calculateEstimate(
    input.serviceTierId,
    normalizedSize,
    input.condition ?? "moderate"
  );

  const validSlot = TIME_WINDOWS.includes(
    input.timeWindow as (typeof TIME_WINDOWS)[number]
  )
    ? input.timeWindow
    : getAvailableSlotsForDate(input.date)[0] ?? TIME_WINDOWS[0];

  const record: BookingRecord = {
    id: generateBookingId(),
    customerName: input.customerName.trim(),
    contact: input.contact.trim(),
    location: input.location.trim(),
    vehicleDescription: input.vehicleDescription.trim(),
    vehicleSize: normalizedSize,
    serviceTierId: estimate.tier.id,
    serviceTierName: estimate.tier.name,
    date: input.date,
    timeWindow: validSlot,
    interiorAccessMethod:
      input.interiorAccessMethod?.trim() ||
      (estimate.requiresInteriorAccess
        ? "Client will leave vehicle unlocked"
        : "Exterior only (no interior access required)"),
    paymentMethodPreference:
      input.paymentMethodPreference?.trim() || "Major Credit Card",
    estimatedDuration: estimate.durationLabel,
    estimatedPrice: estimate.estimatedPrice,
    checklistStepCompleted: 0,
    status: "Scheduled",
    createdAt: new Date().toISOString(),
  };

  bookings.unshift(record);
  return record;
}

const estimateServiceDeclaration: FunctionDeclaration = {
  name: "estimate_service",
  description:
    "Calculate estimated duration (always 1 to 3 hours) and price in South African Rands (ZAR / R) for an EcoClean Mobile Car Detailing service tier based on vehicle size and condition.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      serviceTierId: {
        type: Type.STRING,
        description:
          "One of: exterior_refresh, complete_eco, signature_bio",
      },
      vehicleSize: {
        type: Type.STRING,
        description: "One of: sedan, suv, bakkie_mpv",
      },
      condition: {
        type: Type.STRING,
        description: "One of: light, moderate, heavy",
      },
    },
    required: ["serviceTierId", "vehicleSize"],
  },
};

const checkAvailabilityDeclaration: FunctionDeclaration = {
  name: "check_availability",
  description:
    "Check available mobile detailing time windows for a specific date (YYYY-MM-DD).",
  parameters: {
    type: Type.OBJECT,
    properties: {
      date: {
        type: Type.STRING,
        description: "Requested date in YYYY-MM-DD format.",
      },
    },
    required: ["date"],
  },
};

const createBookingDeclaration: FunctionDeclaration = {
  name: "create_booking",
  description:
    "Book an EcoClean Mobile Car Detailing appointment once you have the client's name, contact (email or cellphone number), service address/location, vehicle description, vehicle size, service tier, date, and preferred time window.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      customerName: { type: Type.STRING, description: "Client full name." },
      contact: {
        type: Type.STRING,
        description: "Client email address or cellphone number.",
      },
      location: {
        type: Type.STRING,
        description:
          "Street address, estate, complex, or office parkade for mobile service.",
      },
      vehicleDescription: {
        type: Type.STRING,
        description: "Year, make, model, or vehicle description.",
      },
      vehicleSize: {
        type: Type.STRING,
        description: "One of: sedan, suv, bakkie_mpv",
      },
      serviceTierId: {
        type: Type.STRING,
        description:
          "One of: exterior_refresh, complete_eco, signature_bio",
      },
      condition: {
        type: Type.STRING,
        description: "Optional condition: light, moderate, heavy",
      },
      date: {
        type: Type.STRING,
        description: "Appointment date in YYYY-MM-DD format.",
      },
      timeWindow: {
        type: Type.STRING,
        description: "Preferred time slot: 08:30, 11:00, 13:30, or 16:00.",
      },
      interiorAccessMethod: {
        type: Type.STRING,
        description:
          "How the technician accesses the interior if interior work is requested (e.g., unlocked remotely, keys left in lockbox, client home, or exterior only).",
      },
      paymentMethodPreference: {
        type: Type.STRING,
        description:
          "Preferred payment method: Major Credit Card, Electronic Funds Transfer (EFT), or Mobile App Payment.",
      },
    },
    required: [
      "customerName",
      "contact",
      "location",
      "vehicleDescription",
      "vehicleSize",
      "serviceTierId",
      "date",
      "timeWindow",
    ],
  },
};

const lookupBookingDeclaration: FunctionDeclaration = {
  name: "lookup_booking",
  description:
    "Look up an existing EcoClean booking and its 5-step operational checklist progress by booking ID (e.g. EC-4812) or client contact/name.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description: "Booking ID (e.g. EC-4812), email, or client name.",
      },
    },
    required: ["query"],
  },
};

const SYSTEM_INSTRUCTION = `You are the automated customer service agent for ${BUSINESS_PROFILE.name}.

Language & Currency Rules (STRICT):
- Write exclusively in South African Standard English (e.g., sanitisation, neutralisation, tyre, microfibre, boot, bakkie, parkade, complex, itemised, programme, customisable, centre).
- Always quote and display prices exclusively in South African Rands (R / ZAR), such as R850 or R1 050. Never use US dollars ($).

Business Profile & Ground Truth:
- Business Name: ${BUSINESS_PROFILE.name}
- Service Overview: ${BUSINESS_PROFILE.serviceOverview}
- Standard Duration: ${BUSINESS_PROFILE.durationSummary}
- Payment Methods Accepted: ${BUSINESS_PROFILE.paymentSummary}
- Product Safety: ${BUSINESS_PROFILE.safetySummary}
- Client Presence Policy: ${BUSINESS_PROFILE.presenceSummary}

Knowledge Base FAQs:
${FAQ_ITEMS.map((f) => `- Q: ${f.question}\n  A: ${f.answer}`).join("\n")}

Service Tiers (South African Rands):
${SERVICE_TIERS.map(
  (t) =>
    `- ${t.name} (id: ${t.id}): ${t.durationRange}. Prices: Hatchback/Sedan ${formatZar(
      t.prices.sedan
    )}, SUV ${formatZar(t.prices.suv)}, Bakkie/MPV ${formatZar(
      t.prices.bakkie_mpv
    )}. Requires interior unlock: ${
      t.requiresInteriorAccess ? "Yes" : "No (exterior only)"
    }. Highlights: ${t.highlights.join("; ")}.`
).join("\n")}

5-Step Operational Checklist (used for every appointment):
${OPERATIONAL_CHECKLIST.map(
  (s) => `${s.stepNumber}. ${s.title} (${s.clientProtocol})`
).join("\n")}

Today's date is ${new Date().toISOString().slice(0, 10)}.

Behaviour & Guidelines:
- Be warm, concise, practical, and accurate. Never invent services, chemical claims, or payment options outside our ground truth.
- Always state clearly when answering presence questions that the client does NOT need to be home, as long as the vehicle is accessible and unlocked if interior work is requested.
- When asked about safety for pets or children, confirm that EcoClean exclusively uses non-toxic, biodegradable formulas.
- When asked about duration, cite 1 to 3 hours depending on vehicle size and condition, and use \`estimate_service\` when they specify a tier or vehicle.
- When asked about payment methods, cite all major credit cards, EFT, and mobile payments via our app.
- If the client wants to book a detail, check availability with \`check_availability\` if helpful, collect any missing details cleanly in one brief message (name, email/cellphone, address, vehicle & size, tier, date/time, and interior access plan if interior work is included), and call \`create_booking\` once you have them.
- Keep responses scannable with short paragraphs or concise bullet points.`;

interface ClientChatMessage {
  role: "user" | "assistant";
  content: string;
}

interface ToolEvent {
  name: string;
  summary: string;
  data: unknown;
}

function executeToolCall(
  name: string,
  args: Record<string, unknown>
): { result: Record<string, unknown>; event: ToolEvent; booking?: BookingRecord } {
  if (name === "estimate_service") {
    const tierId = (args.serviceTierId as ServiceTierId) || "complete_eco";
    const size = normalizeVehicleSize(args.vehicleSize);
    const condition = (args.condition as VehicleCondition) || "moderate";
    const estimate = calculateEstimate(tierId, size, condition);
    const payload = {
      serviceTier: estimate.tier.name,
      serviceTierId: estimate.tier.id,
      vehicleSize: size,
      condition,
      estimatedDuration: estimate.durationLabel,
      currency: "ZAR",
      estimatedPriceZar: estimate.estimatedPrice,
      formattedPrice: estimate.formattedPrice,
      requiresInteriorUnlock: estimate.requiresInteriorAccess,
    };
    return {
      result: payload,
      event: {
        name,
        summary: `${estimate.tier.name} · ${estimate.durationLabel} · ${estimate.formattedPrice}`,
        data: payload,
      },
    };
  }

  if (name === "check_availability") {
    const date =
      typeof args.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(args.date)
        ? args.date
        : new Date().toISOString().slice(0, 10);
    const availableSlots = getAvailableSlotsForDate(date);
    const payload = {
      date,
      availableSlots,
      allWindows: TIME_WINDOWS,
    };
    return {
      result: payload,
      event: {
        name,
        summary: `${availableSlots.length} open windows on ${date}`,
        data: payload,
      },
    };
  }

  if (name === "create_booking") {
    const booking = createBookingRecord({
      customerName: String(args.customerName || "Valued Client"),
      contact: String(args.contact || ""),
      location: String(args.location || ""),
      vehicleDescription: String(args.vehicleDescription || "Vehicle"),
      vehicleSize: normalizeVehicleSize(args.vehicleSize),
      serviceTierId: (args.serviceTierId as ServiceTierId) || "complete_eco",
      condition: (args.condition as VehicleCondition) || "moderate",
      date:
        typeof args.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(args.date)
          ? args.date
          : new Date().toISOString().slice(0, 10),
      timeWindow: String(args.timeWindow || TIME_WINDOWS[0]),
      interiorAccessMethod: args.interiorAccessMethod
        ? String(args.interiorAccessMethod)
        : undefined,
      paymentMethodPreference: args.paymentMethodPreference
        ? String(args.paymentMethodPreference)
        : undefined,
    });
    return {
      result: {
        confirmed: true,
        booking,
        formattedPrice: formatZar(booking.estimatedPrice),
      },
      event: {
        name,
        summary: `Confirmed ${booking.id} · ${booking.date} at ${booking.timeWindow} · ${formatZar(
          booking.estimatedPrice
        )}`,
        data: booking,
      },
      booking,
    };
  }

  if (name === "lookup_booking") {
    const q = String(args.query || "").trim().toLowerCase();
    const match = bookings.find(
      (b) =>
        b.id.toLowerCase() === q ||
        b.contact.toLowerCase().includes(q) ||
        b.customerName.toLowerCase().includes(q)
    );
    const payload = match
      ? {
          found: true,
          booking: match,
          formattedPrice: formatZar(match.estimatedPrice),
          currentStep:
            OPERATIONAL_CHECKLIST[
              Math.min(
                match.checklistStepCompleted,
                OPERATIONAL_CHECKLIST.length - 1
              )
            ],
        }
      : {
          found: false,
          message: `No booking found matching "${args.query}". Try EC-4812 as a sample booking reference.`,
        };
    return {
      result: payload,
      event: {
        name,
        summary: match
          ? `Found ${match.id} (${match.status})`
          : `No booking match for "${args.query}"`,
        data: payload,
      },
      booking: match,
    };
  }

  return {
    result: { error: `Unknown tool: ${name}` },
    event: { name, summary: `Unknown tool ${name}`, data: null },
  };
}

function isTransientError(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  return (
    msg.includes("503") ||
    msg.includes("UNAVAILABLE") ||
    msg.includes("429") ||
    msg.includes("RESOURCE_EXHAUSTED") ||
    msg.includes("ETIMEDOUT") ||
    msg.includes("ECONNRESET")
  );
}

async function generateWithRetry(
  ai: GoogleGenAI,
  contents: Content[],
  tools: { functionDeclarations: FunctionDeclaration[] }[]
) {
  const delays = [500, 1200];
  let lastError: unknown;
  for (let attempt = 0; attempt <= delays.length; attempt++) {
    try {
      return await ai.models.generateContent({
        model: MODEL_NAME,
        contents,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          tools,
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        },
      });
    } catch (err) {
      lastError = err;
      if (attempt < delays.length && isTransientError(err)) {
        await new Promise((resolve) => setTimeout(resolve, delays[attempt]));
        continue;
      }
      throw err;
    }
  }
  throw lastError;
}

function formatGeminiError(err: unknown): { status: number; message: string } {
  let rawMsg = err instanceof Error ? err.message : String(err);

  // Extract readable nested message if SDK serialized JSON error
  try {
    const parsed = JSON.parse(rawMsg) as {
      error?: { code?: number; message?: string; status?: string };
    };
    if (parsed?.error?.message) {
      rawMsg = `${parsed.error.status ?? ""} ${parsed.error.code ?? ""}: ${
        parsed.error.message
      }`.trim();
    }
  } catch {
    // Keep raw message if not JSON
  }

  if (rawMsg.includes("GEMINI_API_KEY is not configured")) {
    return { status: 500, message: rawMsg };
  }
  if (rawMsg.includes("PERMISSION_DENIED") || rawMsg.includes("403")) {
    return {
      status: 403,
      message:
        "Gemini API permission denied (403). Please verify your API key in Settings > Secrets.",
    };
  }
  if (rawMsg.includes("API_KEY_INVALID") || rawMsg.includes("400")) {
    return {
      status: 400,
      message:
        "Gemini API request or key is invalid (400). Please check your API key in Settings > Secrets.",
    };
  }
  if (rawMsg.includes("RESOURCE_EXHAUSTED") || rawMsg.includes("429")) {
    return {
      status: 429,
      message:
        "Our automated concierge is experiencing high request volume (429). Please wait a moment and select Retry.",
    };
  }
  if (rawMsg.includes("503") || rawMsg.includes("UNAVAILABLE")) {
    return {
      status: 503,
      message:
        "Our automated concierge model is temporarily busy. Please wait a few seconds and select Retry.",
    };
  }
  return {
    status: 500,
    message: rawMsg || "Unable to reach the automated customer service agent.",
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "1mb" }));

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, service: BUSINESS_PROFILE.name, currency: "ZAR" });
  });

  app.get("/api/bookings", (_req, res) => {
    res.json({ bookings });
  });

  app.get("/api/availability", (req, res) => {
    const date =
      typeof req.query.date === "string" &&
      /^\d{4}-\d{2}-\d{2}$/.test(req.query.date)
        ? req.query.date
        : new Date().toISOString().slice(0, 10);
    res.json({
      date,
      availableSlots: getAvailableSlotsForDate(date),
      allWindows: TIME_WINDOWS,
    });
  });

  app.post("/api/bookings", (req, res) => {
    const body = req.body ?? {};
    const required = [
      "customerName",
      "contact",
      "location",
      "vehicleDescription",
      "vehicleSize",
      "serviceTierId",
      "date",
      "timeWindow",
    ];
    for (const field of required) {
      if (!body[field] || String(body[field]).trim() === "") {
        return res
          .status(400)
          .json({ error: `Missing required field: ${field}` });
      }
    }

    const booking = createBookingRecord({
      customerName: String(body.customerName),
      contact: String(body.contact),
      location: String(body.location),
      vehicleDescription: String(body.vehicleDescription),
      vehicleSize: normalizeVehicleSize(body.vehicleSize),
      serviceTierId: body.serviceTierId as ServiceTierId,
      condition: (body.condition as VehicleCondition) || "moderate",
      date: String(body.date),
      timeWindow: String(body.timeWindow),
      interiorAccessMethod: body.interiorAccessMethod
        ? String(body.interiorAccessMethod)
        : undefined,
      paymentMethodPreference: body.paymentMethodPreference
        ? String(body.paymentMethodPreference)
        : PAYMENT_METHODS[0],
    });

    return res.status(201).json({ booking });
  });

  app.patch("/api/bookings/:id/checklist", (req, res) => {
    const booking = bookings.find((b) => b.id === req.params.id);
    if (!booking) {
      return res.status(404).json({ error: "Booking not found." });
    }
    const step = Number(req.body?.step);
    if (Number.isNaN(step) || step < 0 || step > 5) {
      return res
        .status(400)
        .json({ error: "Checklist step must be between 0 and 5." });
    }
    booking.checklistStepCompleted = step;
    booking.status =
      step === 0 ? "Scheduled" : step < 5 ? "In Progress" : "Completed";
    return res.json({ booking });
  });

  app.post("/api/agent/chat", async (req, res) => {
    try {
      const clientMessages = (req.body?.messages ?? []) as ClientChatMessage[];
      if (!Array.isArray(clientMessages) || clientMessages.length === 0) {
        return res
          .status(400)
          .json({ error: "Conversation messages are required." });
      }

      const ai = getAiClient();
      const contents: Content[] = clientMessages.map((m) => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }],
      }));

      const tools = [
        {
          functionDeclarations: [
            estimateServiceDeclaration,
            checkAvailabilityDeclaration,
            createBookingDeclaration,
            lookupBookingDeclaration,
          ],
        },
      ];

      const toolEvents: ToolEvent[] = [];
      let affectedBooking: BookingRecord | undefined;
      let finalReply = "";

      for (let round = 0; round < 4; round++) {
        const response = await generateWithRetry(ai, contents, tools);

        const candidateContent = response.candidates?.[0]?.content;
        const functionCalls = response.functionCalls;

        if (functionCalls && functionCalls.length > 0 && candidateContent) {
          contents.push(candidateContent);
          const responseParts = functionCalls.map((fc) => {
            const executed = executeToolCall(
              fc.name ?? "",
              (fc.args ?? {}) as Record<string, unknown>
            );
            toolEvents.push(executed.event);
            if (executed.booking) {
              affectedBooking = executed.booking;
            }
            return {
              functionResponse: {
                id: fc.id,
                name: fc.name ?? "",
                response: executed.result,
              },
            };
          });
          contents.push({
            role: "user",
            parts: responseParts,
          });
          continue;
        }

        finalReply = (response.text ?? "").trim();
        break;
      }

      if (!finalReply) {
        finalReply =
          "I have processed your request. Please let me know if you need any further details on our waterless detailing tiers, Rand pricing, or appointment windows.";
      }

      return res.json({
        reply: finalReply,
        toolEvents,
        booking: affectedBooking ?? null,
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      return res.status(formatted.status).json({ error: formatted.message });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, "dist");
    if (fs.existsSync(distDir)) {
      app.use(express.static(distDir));
      app.get("*", (_req, res) => {
        res.sendFile(path.join(distDir, "index.html"));
      });
    }
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`EcoClean server listening on http://localhost:${PORT}`);
  });
}

startServer();
