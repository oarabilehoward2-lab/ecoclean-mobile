export type VehicleSize = "sedan" | "suv" | "bakkie_mpv";
export type ServiceTierId = "exterior_refresh" | "complete_eco" | "signature_bio";
export type VehicleCondition = "light" | "moderate" | "heavy";

export interface ServiceTier {
  id: ServiceTierId;
  name: string;
  summary: string;
  durationRange: string;
  estimatedMinutes: Record<VehicleSize, number>;
  prices: Record<VehicleSize, number>;
  requiresInteriorAccess: boolean;
  highlights: string[];
}

export interface FaqEntry {
  id: string;
  category: "Logistics" | "Payments" | "Timing" | "Safety";
  question: string;
  answer: string;
  followUpPrompt: string;
}

export interface ChecklistStep {
  stepNumber: number;
  title: string;
  clientProtocol: string;
  technicianAction: string;
}

export interface BookingRecord {
  id: string;
  customerName: string;
  contact: string;
  location: string;
  vehicleDescription: string;
  vehicleSize: VehicleSize;
  serviceTierId: ServiceTierId;
  serviceTierName: string;
  date: string;
  timeWindow: string;
  interiorAccessMethod: string;
  paymentMethodPreference: string;
  estimatedDuration: string;
  estimatedPrice: number;
  checklistStepCompleted: number; // 0 to 5
  status: "Scheduled" | "In Progress" | "Completed";
  createdAt: string;
}

export function formatZar(amount: number, includeDecimals = false): string {
  const fixed = includeDecimals ? amount.toFixed(2) : Math.round(amount).toString();
  const [whole, dec] = fixed.split(".");
  const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return dec !== undefined ? `R${grouped}.${dec}` : `R${grouped}`;
}

export const BUSINESS_PROFILE = {
  name: "EcoClean Mobile Car Detailing",
  serviceOverview:
    "Waterless, eco-friendly detailing brought directly to client locations.",
  durationSummary:
    "Between one and three hours depending on the vehicle size and condition.",
  paymentSummary:
    "All major credit cards, EFT, and mobile payments via our app.",
  safetySummary:
    "Exclusively non-toxic, biodegradable formulas safe for pets and children.",
  presenceSummary:
    "No need to be home, as long as the vehicle is accessible and unlocked if interior work is requested.",
};

export const TIME_WINDOWS = [
  "08:30",
  "11:00",
  "13:30",
  "16:00",
] as const;

export const PAYMENT_METHODS = [
  "Major Credit Card",
  "Electronic Funds Transfer (EFT)",
  "Mobile App Payment",
] as const;

export const SERVICE_TIERS: ServiceTier[] = [
  {
    id: "exterior_refresh",
    name: "Exterior Waterless Refresh",
    summary:
      "Zero-runoff plant-based exterior wash, wheel care, and streak-free glass polish right in your driveway, complex, or office parkade.",
    durationRange: "1 to 1.5 hours",
    estimatedMinutes: {
      sedan: 60,
      suv: 75,
      bakkie_mpv: 90,
    },
    prices: {
      sedan: 450,
      suv: 550,
      bakkie_mpv: 650,
    },
    requiresInteriorAccess: false,
    highlights: [
      "Waterless biodegradable encapsulant wash",
      "Plush dual-pile microfibre hand buff",
      "Wheel faces, brake dust & eco tyre satin dressing",
      "Exterior glass & mirror clarity treatment",
    ],
  },
  {
    id: "complete_eco",
    name: "Complete Eco Detail",
    summary:
      "Full interior cabin sanitisation and exterior waterless gloss using pet- and child-safe botanical formulas.",
    durationRange: "1.5 to 2.5 hours",
    estimatedMinutes: {
      sedan: 105,
      suv: 125,
      bakkie_mpv: 145,
    },
    prices: {
      sedan: 850,
      suv: 1050,
      bakkie_mpv: 1200,
    },
    requiresInteriorAccess: true,
    highlights: [
      "Full Exterior Waterless Refresh included",
      "Deep cabin, seat crease & boot vacuuming",
      "Non-toxic botanical wipe-down of dash, console & leather",
      "Interior glass, door jambs & floor mat restoration",
    ],
  },
  {
    id: "signature_bio",
    name: "Signature Bio-Protection",
    summary:
      "Deep restoration for family vehicles, pet transport, and high-kilometre commutes with plant-polymer paint protection.",
    durationRange: "2.5 to 3 hours",
    estimatedMinutes: {
      sedan: 150,
      suv: 165,
      bakkie_mpv: 180,
    },
    prices: {
      sedan: 1350,
      suv: 1600,
      bakkie_mpv: 1850,
    },
    requiresInteriorAccess: true,
    highlights: [
      "Full Complete Eco Detail included",
      "Plant-polymer hydrophobic paint sealant (up to 90 days)",
      "Targeted pet hair removal & biodegradable spot extraction",
      "Fragrance-free natural cabin odour neutralisation",
    ],
  },
];

export const FAQ_ITEMS: FaqEntry[] = [
  {
    id: "faq-home",
    category: "Logistics",
    question: "Do I need to be home during the service?",
    answer:
      "No, as long as the vehicle is accessible and unlocked if interior work is requested.",
    followUpPrompt:
      "How should I arrange vehicle access if I am at the office during my interior detail?",
  },
  {
    id: "faq-payment",
    category: "Payments",
    question: "What payment methods do you accept?",
    answer: "All major credit cards, EFT, and mobile payments via our app.",
    followUpPrompt:
      "When is payment processed and how do I receive my digital receipt?",
  },
  {
    id: "faq-duration",
    category: "Timing",
    question: "How long does a standard detail take?",
    answer:
      "Between one and three hours depending on the vehicle size and condition.",
    followUpPrompt:
      "Can you estimate how long a Complete Eco Detail takes for an SUV with moderate pet hair?",
  },
  {
    id: "faq-safety",
    category: "Safety",
    question: "Are your cleaning products safe for pets and children?",
    answer: "Yes, we exclusively use non-toxic, biodegradable formulas.",
    followUpPrompt:
      "Are there any harsh scents or chemical residues left on car seats after detailing?",
  },
];

export const OPERATIONAL_CHECKLIST: ChecklistStep[] = [
  {
    stepNumber: 1,
    title: "Verify vehicle access and keys.",
    clientProtocol:
      "Ensure the vehicle is parked in an accessible bay and unlocked (or keys arranged) if interior detailing is requested.",
    technicianAction:
      "Confirm arrival at client location, verify parking clearance, and confirm interior unlock status or key handoff.",
  },
  {
    stepNumber: 2,
    title: "Perform initial exterior and interior inspection.",
    clientProtocol:
      "Share any trouble spots such as tree sap, coffee spills, or pet hair during booking or arrival.",
    technicianAction:
      "Document pre-existing paint condition, trim wear, and cabin soil level before applying product.",
  },
  {
    stepNumber: 3,
    title: "Execute detailing process according to service tier.",
    clientProtocol:
      "Zero water hook-ups or power outlets needed—our mobile unit brings non-toxic, biodegradable formulas.",
    technicianAction:
      "Apply waterless encapsulant wash, microfibre buffing, and tier-specific interior or polymer care.",
  },
  {
    stepNumber: 4,
    title: "Conduct final quality check with client.",
    clientProtocol:
      "Review the finished vehicle in person or via our technician's post-service photo summary if you are away.",
    technicianAction:
      "Inspect glass, door jambs, wheels, and upholstery against quality standards and confirm client approval.",
  },
  {
    stepNumber: 5,
    title: "Process payment and send digital receipt.",
    clientProtocol:
      "Pay seamlessly via major credit card, EFT, or mobile payment in our app—no cash required.",
    technicianAction:
      "Complete payment transaction, lock vehicle if unattended, and dispatch itemised digital receipt.",
  },
];

export function calculateEstimate(
  serviceTierId: ServiceTierId,
  vehicleSize: VehicleSize,
  condition: VehicleCondition = "moderate"
): {
  tier: ServiceTier;
  estimatedMinutes: number;
  durationLabel: string;
  estimatedPrice: number;
  formattedPrice: string;
  requiresInteriorAccess: boolean;
} {
  const tier =
    SERVICE_TIERS.find((t) => t.id === serviceTierId) ?? SERVICE_TIERS[1];
  const baseMinutes = tier.estimatedMinutes[vehicleSize] ?? 120;
  const conditionDelta =
    condition === "light" ? -15 : condition === "heavy" ? 25 : 0;
  const clampedMinutes = Math.max(60, Math.min(180, baseMinutes + conditionDelta));

  const hours = Math.floor(clampedMinutes / 60);
  const mins = clampedMinutes % 60;
  const durationLabel =
    mins === 0
      ? `${hours} hr${hours > 1 ? "s" : ""}`
      : `${hours} hr${hours > 1 ? "s" : ""} ${mins} min`;

  const basePrice = tier.prices[vehicleSize] ?? 850;
  const conditionPriceDelta = condition === "heavy" ? 150 : 0;
  const estimatedPrice = basePrice + conditionPriceDelta;

  return {
    tier,
    estimatedMinutes: clampedMinutes,
    durationLabel,
    estimatedPrice,
    formattedPrice: formatZar(estimatedPrice),
    requiresInteriorAccess: tier.requiresInteriorAccess,
  };
}
