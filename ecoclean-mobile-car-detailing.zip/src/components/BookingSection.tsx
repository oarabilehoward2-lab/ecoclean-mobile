import { useEffect, useState } from "react";
import { CheckCircle2, AlertCircle } from "lucide-react";
import {
  PAYMENT_METHODS,
  SERVICE_TIERS,
  TIME_WINDOWS,
  calculateEstimate,
  formatZar,
  type BookingRecord,
  type ServiceTierId,
  type VehicleSize,
} from "../data/ecoclean";

interface BookingSectionProps {
  preselectedTier: ServiceTierId;
  preselectedSize: VehicleSize;
  onBookingCreated: (booking: BookingRecord) => void;
}

export function BookingSection({
  preselectedTier,
  preselectedSize,
  onBookingCreated,
}: BookingSectionProps) {
  const today = new Date().toISOString().slice(0, 10);

  const [customerName, setCustomerName] = useState("");
  const [contact, setContact] = useState("");
  const [location, setLocation] = useState("");
  const [vehicleDescription, setVehicleDescription] = useState("");
  const [vehicleSize, setVehicleSize] = useState<VehicleSize>(preselectedSize);
  const [serviceTierId, setServiceTierId] =
    useState<ServiceTierId>(preselectedTier);
  const [date, setDate] = useState(today);
  const [timeWindow, setTimeWindow] = useState<string>(TIME_WINDOWS[0]);
  const [availableSlots, setAvailableSlots] = useState<string[]>([
    ...TIME_WINDOWS,
  ]);
  const [interiorAccessMethod, setInteriorAccessMethod] = useState(
    "Unlocked remotely upon technician arrival"
  );
  const [paymentMethodPreference, setPaymentMethodPreference] =
    useState<string>(PAYMENT_METHODS[0]);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [confirmedBooking, setConfirmedBooking] =
    useState<BookingRecord | null>(null);

  useEffect(() => {
    setServiceTierId(preselectedTier);
  }, [preselectedTier]);

  useEffect(() => {
    setVehicleSize(preselectedSize);
  }, [preselectedSize]);

  useEffect(() => {
    let active = true;
    fetch(`/api/availability?date=${encodeURIComponent(date)}`)
      .then((res) => res.json())
      .then((data) => {
        if (!active) return;
        const slots = Array.isArray(data.availableSlots)
          ? data.availableSlots
          : [...TIME_WINDOWS];
        setAvailableSlots(slots);
        if (slots.length > 0 && !slots.includes(timeWindow)) {
          setTimeWindow(slots[0]);
        }
      })
      .catch(() => {
        if (active) setAvailableSlots([...TIME_WINDOWS]);
      });
    return () => {
      active = false;
    };
  }, [date]);

  const estimate = calculateEstimate(serviceTierId, vehicleSize, "moderate");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);

    if (
      !customerName.trim() ||
      !contact.trim() ||
      !location.trim() ||
      !vehicleDescription.trim()
    ) {
      setFormError(
        "Please complete your full name, email or cellphone number, service address, and vehicle details."
      );
      return;
    }

    const emailOrPhoneValid =
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact.trim()) ||
      /^[+\d()\s-]{7,}$/.test(contact.trim());
    if (!emailOrPhoneValid) {
      setFormError(
        "Please enter a valid email address or South African cellphone number."
      );
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName,
          contact,
          location,
          vehicleDescription,
          vehicleSize,
          serviceTierId,
          date,
          timeWindow,
          interiorAccessMethod: estimate.requiresInteriorAccess
            ? interiorAccessMethod
            : "Exterior only (no interior access required)",
          paymentMethodPreference,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Unable to create booking.");
      }

      const booking = data.booking as BookingRecord;
      setConfirmedBooking(booking);
      onBookingCreated(booking);
    } catch (err) {
      setFormError(
        err instanceof Error ? err.message : "Failed to submit booking."
      );
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <section
      id="booking"
      className="py-20 border-t border-[#E2E8E4] bg-white"
    >
      <div className="max-w-[1200px] mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        {/* Left Summary */}
        <div className="lg:col-span-5 space-y-6">
          <div>
            <p className="text-xs font-medium text-[#14533C] tracking-wide mb-2">
              Direct Mobile Scheduling
            </p>
            <h2 className="text-3xl font-semibold tracking-tight text-[#111815] text-balance">
              Reserve your driveway, complex, or office parkade slot.
            </h2>
            <p className="mt-3 text-sm text-[#4B5953] leading-relaxed">
              Our mobile technicians arrive self-contained with waterless,
              non-toxic, biodegradable formulas. You do not need to be home—just
              ensure your vehicle is accessible and unlocked if interior work is
              requested.
            </p>
          </div>

          <div className="bg-[#F8FAF8] border border-[#DCE4DF] rounded-xl p-5 space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-[#596861]">Selected Tier</span>
              <span className="font-medium text-[#111815]">
                {estimate.tier.name}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#596861]">Estimated Time</span>
              <span className="font-mono tabular-nums font-medium text-[#111815]">
                {estimate.durationLabel}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#596861]">Interior Access</span>
              <span className="font-medium text-[#111815]">
                {estimate.requiresInteriorAccess
                  ? "Unlock required"
                  : "Not required"}
              </span>
            </div>
            <div className="pt-3 border-t border-[#E2E8E4] flex justify-between items-baseline">
              <span className="font-semibold text-[#111815]">
                Estimated Total
              </span>
              <span className="text-xl font-semibold font-mono tabular-nums text-[#14533C]">
                {formatZar(estimate.estimatedPrice, true)}
              </span>
            </div>
          </div>

          <div className="text-xs text-[#596861] space-y-1.5">
            <p>
              Accepted payments: All major credit cards, EFT, and mobile
              payments via our app.
            </p>
            <p>
              All appointments follow our 5-step operational quality checklist.
            </p>
          </div>
        </div>

        {/* Right Form */}
        <div className="lg:col-span-7 bg-[#F8FAF8] border border-[#DCE4DF] rounded-xl p-6 md:p-8">
          {confirmedBooking ? (
            <div className="space-y-5">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-[#14533C] shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-xl font-semibold text-[#111815]">
                    Appointment Scheduled —{" "}
                    <span className="font-mono tabular-nums">
                      {confirmedBooking.id}
                    </span>
                  </h3>
                  <p className="text-sm text-[#4B5953] mt-1">
                    Confirmed for {confirmedBooking.date} at{" "}
                    {confirmedBooking.timeWindow} (
                    {confirmedBooking.estimatedDuration}). Your booking is now
                    linked to the 5-step Operational Checklist above.
                  </p>
                </div>
              </div>

              <div className="bg-white border border-[#DCE4DF] rounded-lg p-4 text-sm space-y-2">
                <div className="flex justify-between">
                  <span className="text-[#596861]">Location</span>
                  <span className="font-medium text-[#111815]">
                    {confirmedBooking.location}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#596861]">Access Plan</span>
                  <span className="font-medium text-[#111815]">
                    {confirmedBooking.interiorAccessMethod}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#596861]">Payment Preference</span>
                  <span className="font-medium text-[#111815]">
                    {confirmedBooking.paymentMethodPreference}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-[#E7ECE9]">
                  <span className="text-[#111815] font-semibold">Estimate</span>
                  <span className="font-semibold font-mono tabular-nums text-[#14533C]">
                    {formatZar(confirmedBooking.estimatedPrice, true)}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <a
                  href="#checklist"
                  className="px-4 py-2 text-sm font-medium text-white bg-[#14533C] hover:bg-[#0F402E] rounded-lg transition-colors"
                >
                  Track Operational Checklist
                </a>
                <button
                  type="button"
                  onClick={() => setConfirmedBooking(null)}
                  className="px-4 py-2 text-sm font-medium text-[#111815] bg-white border border-[#DCE4DF] hover:border-[#14533C] rounded-lg transition-colors cursor-pointer"
                >
                  Book Another Vehicle
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {formError && (
                <div
                  role="alert"
                  className="flex items-start gap-2.5 p-3.5 rounded-lg bg-[#FDF2F2] border border-[#F3D1D1] text-xs text-[#8C1D1D]"
                >
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{formError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="booking-name"
                    className="block text-xs font-medium text-[#2E3D37] mb-1.5"
                  >
                    Full Name
                  </label>
                  <input
                    id="booking-name"
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Lerato Ndlovu"
                    className="w-full h-10 px-3 text-sm bg-white border border-[#DCE4DF] rounded-lg text-[#111815] focus:outline-none focus:border-[#14533C]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="booking-contact"
                    className="block text-xs font-medium text-[#2E3D37] mb-1.5"
                  >
                    Email or Cellphone Number
                  </label>
                  <input
                    id="booking-contact"
                    type="text"
                    required
                    value={contact}
                    onChange={(e) => setContact(e.target.value)}
                    placeholder="lerato@example.co.za or 082 555 0142"
                    className="w-full h-10 px-3 text-sm bg-white border border-[#DCE4DF] rounded-lg text-[#111815] focus:outline-none focus:border-[#14533C]"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="booking-location"
                  className="block text-xs font-medium text-[#2E3D37] mb-1.5"
                >
                  Service Address & Parking Bay
                </label>
                <input
                  id="booking-location"
                  type="text"
                  required
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="24 Protea Road, Claremont, Cape Town (Driveway or Office Parkade)"
                  className="w-full h-10 px-3 text-sm bg-white border border-[#DCE4DF] rounded-lg text-[#111815] focus:outline-none focus:border-[#14533C]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="booking-vehicle"
                    className="block text-xs font-medium text-[#2E3D37] mb-1.5"
                  >
                    Vehicle Year, Make & Model
                  </label>
                  <input
                    id="booking-vehicle"
                    type="text"
                    required
                    value={vehicleDescription}
                    onChange={(e) => setVehicleDescription(e.target.value)}
                    placeholder="2023 Toyota Corolla Cross"
                    className="w-full h-10 px-3 text-sm bg-white border border-[#DCE4DF] rounded-lg text-[#111815] focus:outline-none focus:border-[#14533C]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="booking-size"
                    className="block text-xs font-medium text-[#2E3D37] mb-1.5"
                  >
                    Vehicle Size
                  </label>
                  <select
                    id="booking-size"
                    value={vehicleSize}
                    onChange={(e) =>
                      setVehicleSize(e.target.value as VehicleSize)
                    }
                    className="w-full h-10 px-3 text-sm bg-white border border-[#DCE4DF] rounded-lg text-[#111815] focus:outline-none focus:border-[#14533C]"
                  >
                    <option value="sedan">Hatchback / Sedan</option>
                    <option value="suv">SUV / Crossover</option>
                    <option value="bakkie_mpv">Bakkie / 4x4 / MPV</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label
                    htmlFor="booking-tier"
                    className="block text-xs font-medium text-[#2E3D37] mb-1.5"
                  >
                    Service Tier
                  </label>
                  <select
                    id="booking-tier"
                    value={serviceTierId}
                    onChange={(e) =>
                      setServiceTierId(e.target.value as ServiceTierId)
                    }
                    className="w-full h-10 px-3 text-sm bg-white border border-[#DCE4DF] rounded-lg text-[#111815] focus:outline-none focus:border-[#14533C]"
                  >
                    {SERVICE_TIERS.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="booking-date"
                    className="block text-xs font-medium text-[#2E3D37] mb-1.5"
                  >
                    Preferred Date
                  </label>
                  <input
                    id="booking-date"
                    type="date"
                    min={today}
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full h-10 px-3 text-sm bg-white border border-[#DCE4DF] rounded-lg text-[#111815] font-mono focus:outline-none focus:border-[#14533C]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="booking-window"
                    className="block text-xs font-medium text-[#2E3D37] mb-1.5"
                  >
                    Arrival Window
                  </label>
                  <select
                    id="booking-window"
                    value={timeWindow}
                    onChange={(e) => setTimeWindow(e.target.value)}
                    className="w-full h-10 px-3 text-sm bg-white border border-[#DCE4DF] rounded-lg text-[#111815] font-mono focus:outline-none focus:border-[#14533C]"
                  >
                    {(availableSlots.length > 0
                      ? availableSlots
                      : TIME_WINDOWS
                    ).map((slot) => (
                      <option key={slot} value={slot}>
                        {slot}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="booking-access"
                    className="block text-xs font-medium text-[#2E3D37] mb-1.5"
                  >
                    Vehicle Access Plan
                  </label>
                  <select
                    id="booking-access"
                    disabled={!estimate.requiresInteriorAccess}
                    value={
                      estimate.requiresInteriorAccess
                        ? interiorAccessMethod
                        : "Exterior only (no interior access required)"
                    }
                    onChange={(e) => setInteriorAccessMethod(e.target.value)}
                    className="w-full h-10 px-3 text-sm bg-white border border-[#DCE4DF] rounded-lg text-[#111815] disabled:bg-[#EFF3F0] disabled:text-[#596861] focus:outline-none focus:border-[#14533C]"
                  >
                    {estimate.requiresInteriorAccess ? (
                      <>
                        <option value="Unlocked remotely upon technician arrival">
                          Unlocked remotely upon arrival
                        </option>
                        <option value="Vehicle left unlocked in private driveway">
                          Left unlocked in private driveway
                        </option>
                        <option value="Keys in lockbox or with security/reception">
                          Keys in lockbox / with security
                        </option>
                        <option value="I will be home to meet technician">
                          I will be home in person
                        </option>
                      </>
                    ) : (
                      <option value="Exterior only (no interior access required)">
                        Exterior only (no unlock needed)
                      </option>
                    )}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="booking-payment"
                    className="block text-xs font-medium text-[#2E3D37] mb-1.5"
                  >
                    Payment Method
                  </label>
                  <select
                    id="booking-payment"
                    value={paymentMethodPreference}
                    onChange={(e) =>
                      setPaymentMethodPreference(e.target.value)
                    }
                    className="w-full h-10 px-3 text-sm bg-white border border-[#DCE4DF] rounded-lg text-[#111815] focus:outline-none focus:border-[#14533C]"
                  >
                    {PAYMENT_METHODS.map((pm) => (
                      <option key={pm} value={pm}>
                        {pm}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full h-11 bg-[#14533C] hover:bg-[#0F402E] disabled:bg-[#9FB3AA] text-white text-sm font-medium rounded-lg transition-colors cursor-pointer"
              >
                {isSubmitting
                  ? "Confirming Appointment..."
                  : "Confirm Mobile Detailing Appointment"}
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
