import { useState } from "react";
import { Check, FileText, Search } from "lucide-react";
import {
  OPERATIONAL_CHECKLIST,
  formatZar,
  type BookingRecord,
} from "../data/ecoclean";

interface OperationalChecklistProps {
  activeBooking: BookingRecord;
  bookings: BookingRecord[];
  onSelectBooking: (booking: BookingRecord) => void;
  onUpdateStep: (bookingId: string, step: number) => Promise<void>;
}

export function OperationalChecklist({
  activeBooking,
  bookings,
  onSelectBooking,
  onUpdateStep,
}: OperationalChecklistProps) {
  const [lookupInput, setLookupInput] = useState("");
  const [lookupFeedback, setLookupFeedback] = useState<string | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const [showReceipt, setShowReceipt] = useState(false);

  async function handleStepClick(stepNumber: number) {
    if (isUpdating) return;
    setIsUpdating(true);
    try {
      const nextStep =
        activeBooking.checklistStepCompleted === stepNumber
          ? stepNumber - 1
          : stepNumber;
      await onUpdateStep(activeBooking.id, nextStep);
    } finally {
      setIsUpdating(false);
    }
  }

  function handleLookup(e: React.FormEvent) {
    e.preventDefault();
    const q = lookupInput.trim().toLowerCase();
    if (!q) return;
    const found = bookings.find(
      (b) =>
        b.id.toLowerCase() === q ||
        b.customerName.toLowerCase().includes(q) ||
        b.contact.toLowerCase().includes(q)
    );
    if (found) {
      onSelectBooking(found);
      setLookupFeedback(null);
      setShowReceipt(false);
    } else {
      setLookupFeedback(`No appointment found matching "${lookupInput}".`);
    }
  }

  return (
    <section id="checklist" className="py-20 border-t border-[#E2E8E4] bg-white">
      <div className="max-w-[1200px] mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-[#14533C] tracking-wide mb-2">
              Standard Operating Protocol
            </p>
            <h2 className="text-3xl md:text-4xl font-semibold tracking-tight text-[#111815] text-balance">
              Five-step operational checklist from arrival to digital receipt.
            </h2>
          </div>

          <form
            onSubmit={handleLookup}
            className="flex items-center gap-2 self-start md:self-auto"
          >
            <label htmlFor="booking-lookup" className="sr-only">
              Look up booking reference
            </label>
            <input
              id="booking-lookup"
              type="text"
              value={lookupInput}
              onChange={(e) => setLookupInput(e.target.value)}
              placeholder="Booking ref (e.g. EC-4812)"
              className="h-10 w-48 px-3 text-sm bg-[#F8FAF8] border border-[#DCE4DF] rounded-lg text-[#111815] placeholder:text-[#73827B] focus:outline-none focus:border-[#14533C]"
            />
            <button
              type="submit"
              className="h-10 px-3.5 inline-flex items-center gap-1.5 text-sm font-medium bg-[#F2F6F4] hover:bg-[#E4ECE8] text-[#111815] rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Search className="w-4 h-4" />
              <span>Track</span>
            </button>
          </form>
        </div>

        {lookupFeedback && (
          <p className="mb-6 text-sm text-[#8C1D1D]">{lookupFeedback}</p>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: 5-Step Operational Checklist */}
          <div className="lg:col-span-7 divide-y divide-[#E7ECE9] border-y border-[#E7ECE9]">
            {OPERATIONAL_CHECKLIST.map((step) => {
              const isDone =
                activeBooking.checklistStepCompleted >= step.stepNumber;
              const isCurrent =
                activeBooking.checklistStepCompleted + 1 === step.stepNumber;

              return (
                <div
                  key={step.stepNumber}
                  className="py-5 flex items-start justify-between gap-4"
                >
                  <div className="flex items-start gap-4">
                    <span
                      className={`font-mono text-sm tabular-nums pt-0.5 shrink-0 ${
                        isDone
                          ? "text-[#14533C] font-semibold"
                          : isCurrent
                          ? "text-[#111815] font-semibold"
                          : "text-[#7A8A83]"
                      }`}
                    >
                      0{step.stepNumber}.
                    </span>
                    <div>
                      <h3 className="text-base font-semibold text-[#111815]">
                        {step.title}
                      </h3>
                      <p className="text-sm text-[#4B5953] mt-1 leading-relaxed">
                        {step.technicianAction}
                      </p>
                      <p className="text-xs text-[#6B7A73] mt-1.5">
                        Client note: {step.clientProtocol}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={isUpdating}
                    onClick={() => void handleStepClick(step.stepNumber)}
                    aria-pressed={isDone}
                    className={`h-9 px-3 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center gap-1.5 ${
                      isDone
                        ? "bg-[#14533C] border-[#14533C] text-white"
                        : "bg-white border-[#DCE4DF] text-[#2E3D37] hover:border-[#14533C]"
                    }`}
                  >
                    {isDone && <Check className="w-3.5 h-3.5" />}
                    <span>{isDone ? "Completed" : "Mark Step"}</span>
                  </button>
                </div>
              );
            })}
          </div>

          {/* Right: Active Appointment Summary & Digital Receipt Preview */}
          <div className="lg:col-span-5 bg-[#F8FAF8] border border-[#DCE4DF] rounded-xl p-6">
            <div className="flex items-center justify-between gap-3 pb-4 border-b border-[#E2E8E4]">
              <div>
                <p className="text-xs text-[#596861]">Active Service Record</p>
                <h3 className="text-xl font-semibold text-[#111815] font-mono tabular-nums mt-0.5">
                  {activeBooking.id}
                </h3>
              </div>
              <span className="text-xs font-medium text-[#14533C]">
                {activeBooking.status} ·{" "}
                <span className="font-mono tabular-nums">
                  {activeBooking.checklistStepCompleted}/5
                </span>{" "}
                steps
              </span>
            </div>

            <dl className="py-4 space-y-3 text-sm border-b border-[#E2E8E4]">
              <div className="flex justify-between gap-4">
                <dt className="text-[#596861]">Client</dt>
                <dd className="font-medium text-[#111815] text-right">
                  {activeBooking.customerName}
                </dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-[#596861]">Vehicle</dt>
                <dd className="font-medium text-[#111815] text-right">
                  {activeBooking.vehicleDescription}
                </dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-[#596861]">Service Tier</dt>
                <dd className="font-medium text-[#111815] text-right">
                  {activeBooking.serviceTierName}
                </dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-[#596861]">Location</dt>
                <dd className="font-medium text-[#111815] text-right">
                  {activeBooking.location}
                </dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-[#596861]">Window & Duration</dt>
                <dd className="font-medium text-[#111815] text-right font-mono tabular-nums">
                  {activeBooking.date} · {activeBooking.timeWindow} (
                  {activeBooking.estimatedDuration})
                </dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-[#596861]">Access Protocol</dt>
                <dd className="font-medium text-[#111815] text-right">
                  {activeBooking.interiorAccessMethod}
                </dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-[#596861]">Payment Method</dt>
                <dd className="font-medium text-[#111815] text-right">
                  {activeBooking.paymentMethodPreference}
                </dd>
              </div>
              <div className="flex justify-between gap-4 pt-2 border-t border-[#E7ECE9]">
                <dt className="text-[#111815] font-semibold">Total Estimate</dt>
                <dd className="font-semibold text-[#111815] font-mono tabular-nums">
                  {formatZar(activeBooking.estimatedPrice, true)}
                </dd>
              </div>
            </dl>

            <div className="pt-4 flex flex-wrap items-center justify-between gap-3">
              {bookings.length > 1 && (
                <select
                  aria-label="Switch active booking"
                  value={activeBooking.id}
                  onChange={(e) => {
                    const next = bookings.find((b) => b.id === e.target.value);
                    if (next) {
                      onSelectBooking(next);
                      setShowReceipt(false);
                    }
                  }}
                  className="h-9 px-2.5 text-xs bg-white border border-[#DCE4DF] rounded-lg text-[#111815]"
                >
                  {bookings.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.id} — {b.customerName}
                    </option>
                  ))}
                </select>
              )}

              <button
                type="button"
                onClick={() => setShowReceipt((prev) => !prev)}
                className="h-9 px-3.5 text-xs font-medium text-[#14533C] bg-white border border-[#DCE4DF] hover:border-[#14533C] rounded-lg transition-colors inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer ml-auto"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>
                  {showReceipt ? "Hide Digital Receipt" : "Preview Digital Receipt"}
                </span>
              </button>
            </div>

            {showReceipt && (
              <div className="mt-4 p-4 rounded-lg bg-white border border-[#DCE4DF] text-xs space-y-2">
                <div className="flex items-center justify-between font-semibold text-[#111815]">
                  <span>EcoClean Digital Receipt</span>
                  <span className="font-mono tabular-nums">
                    {activeBooking.id}
                  </span>
                </div>
                <p className="text-[#596861]">
                  {activeBooking.serviceTierName} · {activeBooking.vehicleDescription}
                </p>
                <p className="text-[#596861]">
                  Paid via {activeBooking.paymentMethodPreference} · Non-toxic,
                  biodegradable waterless service
                </p>
                <div className="pt-2 border-t border-[#E7ECE9] flex justify-between font-medium text-[#111815]">
                  <span>
                    {activeBooking.checklistStepCompleted === 5
                      ? "Settled & Dispatched"
                      : "Pending Step 5 Completion"}
                  </span>
                  <span className="font-mono tabular-nums">
                    {formatZar(activeBooking.estimatedPrice, true)}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
