import { useState } from "react";
import { CarFront } from "lucide-react";

interface ResilientImageProps {
  src: string;
  alt: string;
  className?: string;
  fallbackLabel?: string;
}

export function ResilientImage({
  src,
  alt,
  className = "",
  fallbackLabel = "EcoClean Mobile Car Detailing",
}: ResilientImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center gap-3 bg-gradient-to-br from-[#EAF1ED] to-[#D8E5DD] text-[#14533C] p-6 ${className}`}
      >
        <CarFront className="w-8 h-8 stroke-[1.5]" />
        <span className="text-sm font-medium text-center text-[#1E3A2F]">
          {fallbackLabel}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
}
