import { useState } from "react";
import { ArrowRight, Search } from "lucide-react";
import { FAQ_ITEMS, type FaqEntry } from "../data/ecoclean";

interface KnowledgeBaseFaqProps {
  onAskAgent: (prompt: string) => void;
}

const CATEGORIES: Array<"All" | FaqEntry["category"]> = [
  "All",
  "Logistics",
  "Payments",
  "Timing",
  "Safety",
];

export function KnowledgeBaseFaq({ onAskAgent }: KnowledgeBaseFaqProps) {
  const [selectedCategory, setSelectedCategory] = useState<
    "All" | FaqEntry["category"]
  >("All");
  const [query, setQuery] = useState("");

  const filtered = FAQ_ITEMS.filter((item) => {
    const matchesCat =
      selectedCategory === "All" || item.category === selectedCategory;
    const q = query.trim().toLowerCase();
    const matchesQuery =
      !q ||
      item.question.toLowerCase().includes(q) ||
      item.answer.toLowerCase().includes(q);
    return matchesCat && matchesQuery;
  });

  return (
    <section id="faq" className="py-20 border-t border-[#E2E8E4]">
      <div className="max-w-[1200px] mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-[#14533C] tracking-wide mb-2">
              Knowledge Base & Policy Reference
            </p>
            <h2 className="text-3xl md:text-4xl font-semibold tracking-tight text-[#111815] text-balance">
              Direct answers grounded in our service policy.
            </h2>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="relative">
              <Search className="w-4 h-4 text-[#6D7C75] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <label htmlFor="faq-search" className="sr-only">
                Search Knowledge Base
              </label>
              <input
                id="faq-search"
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Filter questions..."
                className="h-10 pl-9 pr-3 text-sm bg-white border border-[#DCE4DF] rounded-lg text-[#111815] placeholder:text-[#73827B] focus:outline-none focus:border-[#14533C] w-full sm:w-52"
              />
            </div>

            <div
              role="group"
              aria-label="Filter FAQ by category"
              className="inline-flex items-center p-1 bg-[#EBF0EC] rounded-lg overflow-x-auto"
            >
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    selectedCategory === cat
                      ? "bg-white text-[#111815] shadow-xs"
                      : "text-[#4B5953] hover:text-[#111815]"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="bg-white border border-[#DCE4DF] rounded-xl p-8 text-center">
            <p className="text-sm text-[#4B5953]">
              No knowledge base articles match "{query}". Ask the Automated
              Service Concierge directly for immediate assistance.
            </p>
            <button
              type="button"
              onClick={() => onAskAgent(query)}
              className="mt-4 px-4 py-2 text-sm font-medium text-white bg-[#14533C] hover:bg-[#0F402E] rounded-lg transition-colors cursor-pointer"
            >
              Ask Service Agent
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filtered.map((item, idx) => (
              <article
                key={item.id}
                className="bg-white border border-[#DCE4DF] rounded-xl p-6 flex flex-col justify-between"
              >
                <div>
                  <div className="text-xs text-[#596861] mb-2">
                    <span>0{idx + 1}</span>
                    <span className="mx-1.5" aria-hidden="true">
                      ·
                    </span>
                    <span>{item.category}</span>
                  </div>
                  <h3 className="text-lg font-semibold text-[#111815]">
                    {item.question}
                  </h3>
                  <p className="mt-2.5 text-sm text-[#4B5953] leading-relaxed">
                    {item.answer}
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-[#EBF0EC]">
                  <button
                    type="button"
                    onClick={() => onAskAgent(item.followUpPrompt)}
                    className="inline-flex items-center gap-1.5 text-xs font-medium text-[#14533C] hover:text-[#0F402E] transition-colors cursor-pointer"
                  >
                    <span>Ask Agent Follow-Up</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
