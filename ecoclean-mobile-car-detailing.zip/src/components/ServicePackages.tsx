import { useState } from "react";
import { ArrowRight, Check } from "lucide-react";
import {
  SERVICE_TIERS,
  formatZar,
  type ServiceTierId,
  type VehicleSize,
} from "../data/ecoclean";
import { ResilientImage } from "./ResilientImage";

interface ServicePackagesProps {
  onSelectTier: (tierId: ServiceTierId, vehicleSize: VehicleSize) => void;
  onAskAgent: (prompt: string) => void;
}

const SIZE_LABELS: { id: VehicleSize; label: string }[] = [
  { id: "sedan", label: "Hatchback / Sedan" },
  { id: "suv", label: "SUV / Crossover" },
  { id: "bakkie_mpv", label: "Bakkie / 4x4 / MPV" },
];

export function ServicePackages({
  onSelectTier,
  onAskAgent,
}: ServicePackagesProps) {
  const [selectedSize, setSelectedSize] = useState<VehicleSize>("sedan");

  return (
    <section id="services" className="py-20 border-t border-[#E2E8E4]">
      <div className="max-w-[1200px] mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-[#14533C] tracking-wide mb-2">
              Waterless Detailing Tiers
            </p>
            <h2 className="text-3xl md:text-4xl font-semibold tracking-tight text-[#111815] text-balance">
              Customised mobile care, one to three hours at your location.
            </h2>
          </div>

          <div
            role="group"
            aria-label="Vehicle size pricing selector"
            className="inline-flex items-center p-1 bg-[#EBF0EC] rounded-lg self-start md:self-auto"
          >
            {SIZE_LABELS.map((size) => (
              <button
                key={size.id}
                type="button"
                onClick={() => setSelectedSize(size.id)}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedSize === size.id
                    ? "bg-white text-[#111815] shadow-sm"
                    : "text-[#4B5953] hover:text-[#111815]"
                }`}
              >
                {size.label}
              </button>
            ))}
          </div>
        </div>

        {/* Service Tier Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-12 items-stretch">
          {SERVICE_TIERS.map((tier, index) => {
            const price = tier.prices[selectedSize];
            const mins = tier.estimatedMinutes[selectedSize];
            const hoursText =
              mins % 60 === 0
                ? `${mins / 60} hr${mins > 60 ? "s" : ""}`
                : `${Math.floor(mins / 60)} hr ${mins % 60} min`;

            return (
              <div
                key={tier.id}
                className={`flex flex-col justify-between rounded-xl p-6 border ${
                  tier.id === "complete_eco"
                    ? "bg-white border-[#14533C]"
                    : "bg-white border-[#DCE4DF]"
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-3 text-xs text-[#596861] mb-3">
                    <span>
                      0{index + 1} ·{" "}
                      {tier.requiresInteriorAccess
                        ? "Unlock required"
                        : "Exterior only"}
                    </span>
                    <span className="font-mono tabular-nums text-[#14533C] font-medium">
                      {hoursText}
                    </span>
                  </div>

                  <h3 className="text-xl font-semibold text-[#111815]">
                    {tier.name}
                  </h3>

                  <div className="mt-3 flex items-baseline gap-2">
                    <span className="text-3xl font-semibold text-[#111815] font-mono tabular-nums">
                      {formatZar(price)}
                    </span>
                    <span className="text-xs text-[#596861]">
                      estimated ·{" "}
                      {SIZE_LABELS.find((s) => s.id === selectedSize)?.label}
                    </span>
                  </div>

                  <p className="mt-3 text-sm text-[#4B5953] leading-relaxed">
                    {tier.summary}
                  </p>

                  <ul className="mt-5 pt-5 border-t border-[#EBF0EC] space-y-2.5">
                    {tier.highlights.map((item) => (
                      <li
                        key={item}
                        className="flex items-start gap-2.5 text-sm text-[#26332D]"
                      >
                        <Check className="w-4 h-4 text-[#14533C] shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-6 pt-5 border-t border-[#EBF0EC] flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => onSelectTier(tier.id, selectedSize)}
                    className={`flex-1 h-10 px-4 text-sm font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                      tier.id === "complete_eco"
                        ? "bg-[#14533C] hover:bg-[#0F402E] text-white"
                        : "bg-[#F2F6F4] hover:bg-[#E4ECE8] text-[#111815]"
                    }`}
                  >
                    Book Tier
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      onAskAgent(
                        `Tell me what is included in the ${tier.name} for my ${
                          SIZE_LABELS.find((s) => s.id === selectedSize)?.label
                        } and whether I need to be home.`
                      )
                    }
                    className="h-10 px-3.5 text-sm font-medium text-[#14533C] hover:bg-[#F2F6F4] rounded-lg transition-colors inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <span>Ask Agent</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Asymmetric Visual Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          <div className="lg:col-span-7 relative rounded-xl overflow-hidden border border-[#DCE4DF] bg-[#1C2622]">
            <ResilientImage
              src="/src/assets/images/process_interior_care_1795174016388.jpg"
              alt="EcoClean technician cleaning car interior with plant-based non-toxic mist"
              fallbackLabel="Non-Toxic Interior Detailing"
              className="w-full h-72 lg:h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-6">
              <p className="text-xs text-[#CDE0D6] mb-1">
                Non-toxic · Biodegradable · Zero harsh residue
              </p>
              <h3 className="text-xl font-semibold text-white">
                Safe for pets, children, and daily family vehicles.
              </h3>
            </div>
          </div>

          <div className="lg:col-span-5 relative rounded-xl overflow-hidden border border-[#DCE4DF] bg-[#1C2622]">
            <ResilientImage
              src="/src/assets/images/process_exterior_gloss_1795174015910.jpg"
              alt="Waterless polymer gloss on deep green SUV bonnet with dry paving underneath"
              fallbackLabel="Waterless Polymer Gloss"
              className="w-full h-72 lg:h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-6">
              <p className="text-xs text-[#CDE0D6] mb-1">
                Zero runoff · Complex & office parkade approved
              </p>
              <h3 className="text-xl font-semibold text-white">
                Showroom finish without hoses or driveway puddles.
              </h3>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
