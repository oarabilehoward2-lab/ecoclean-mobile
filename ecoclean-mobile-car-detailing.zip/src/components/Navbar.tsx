interface NavbarProps {
  onBookClick: () => void;
}

export function Navbar({ onBookClick }: NavbarProps) {
  return (
    <header className="sticky top-0 z-40 bg-[#F8FAF8]/95 backdrop-blur-sm border-b border-[#E2E8E4]">
      <div className="max-w-[1200px] mx-auto px-6 h-16 flex items-center justify-between gap-8">
        <a
          href="#top"
          className="font-display text-xl font-bold tracking-tight text-[#111815] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#14533C] rounded-sm"
        >
          EcoClean
        </a>

        <nav
          aria-label="Primary"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-[#4B5953]"
        >
          <a
            href="#assistant"
            className="hover:text-[#111815] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Service Agent
          </a>
          <a
            href="#services"
            className="hover:text-[#111815] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Detailing Tiers
          </a>
          <a
            href="#checklist"
            className="hover:text-[#111815] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Checklist
          </a>
          <a
            href="#faq"
            className="hover:text-[#111815] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Knowledge Base
          </a>
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onBookClick}
            className="px-4 py-2 text-sm font-medium text-white bg-[#14533C] hover:bg-[#0F402E] rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#14533C]"
          >
            Book Detailing
          </button>
        </div>
      </div>
    </header>
  );
}
