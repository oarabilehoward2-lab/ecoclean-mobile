import { useEffect, useRef, useState } from "react";
import { ArrowUp, RotateCcw, AlertCircle, CheckCircle2 } from "lucide-react";
import type { BookingRecord } from "../data/ecoclean";

export interface ChatToolEvent {
  name: string;
  summary: string;
  data?: unknown;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  toolEvents?: ChatToolEvent[];
  timestamp: string;
}

interface AgentConciergeProps {
  externalPrompt: { id: number; text: string } | null;
  onBookingSynced: (booking: BookingRecord) => void;
}

const STORAGE_KEY = "ecoclean_za_chat_history_v1";

const INITIAL_MESSAGE: ChatMessage = {
  id: "welcome-1",
  role: "assistant",
  content:
    "Welcome to EcoClean Mobile Car Detailing. I can assist with questions about our waterless, non-toxic detailing service, estimate service duration and pricing in Rands for your vehicle, check available time slots, or book an appointment at your location.",
  timestamp: new Date().toLocaleTimeString("en-ZA", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }),
};

const QUICK_PROMPTS = [
  "Do I need to be home?",
  "What payment methods do you accept?",
  "How long does a detail take?",
  "Are products safe for pets and children?",
  "Quote a Complete Eco Detail for an SUV",
  "Check status for booking EC-4812",
];

function renderFormattedText(text: string) {
  const lines = text.split("\n");
  return lines.map((line, idx) => {
    const trimmed = line.trim();
    if (!trimmed) {
      return <div key={idx} className="h-2" />;
    }
    const isBullet = trimmed.startsWith("- ") || trimmed.startsWith("* ");
    const cleanLine = isBullet ? trimmed.slice(2) : trimmed;

    const parts = cleanLine.split(/(\*\*[^*]+\*\*)/g).map((segment, sIdx) => {
      if (segment.startsWith("**") && segment.endsWith("**")) {
        return (
          <strong key={sIdx} className="font-semibold text-[#111815]">
            {segment.slice(2, -2)}
          </strong>
        );
      }
      return <span key={sIdx}>{segment}</span>;
    });

    if (isBullet) {
      return (
        <div key={idx} className="flex items-start gap-2 pl-1 my-0.5">
          <span className="text-[#14533C] select-none mt-0.5" aria-hidden="true">
            ·
          </span>
          <p className="leading-relaxed">{parts}</p>
        </div>
      );
    }

    return (
      <p key={idx} className="leading-relaxed">
        {parts}
      </p>
    );
  });
}

export function AgentConcierge({
  externalPrompt,
  onBookingSynced,
}: AgentConciergeProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved) as ChatMessage[];
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // Ignore storage parse failure
    }
    return [INITIAL_MESSAGE];
  });
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const lastExternalPromptId = useRef<number | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
    } catch {
      // Ignore quota errors
    }
  }, [messages]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  async function requestAgentReply(historyToSend: ChatMessage[]) {
    setErrorMessage(null);
    setIsLoading(true);

    try {
      const response = await fetch("/api/agent/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: historyToSend
            .filter((m) => m.id !== "welcome-1")
            .map((m) => ({
              role: m.role,
              content: m.content,
            })),
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(
          data.error || "Unable to reach the automated customer service agent."
        );
      }

      const assistantMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content: data.reply,
        toolEvents: Array.isArray(data.toolEvents) ? data.toolEvents : [],
        timestamp: new Date().toLocaleTimeString("en-ZA", {
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
        }),
      };

      setMessages((prev) => [...prev, assistantMsg]);

      if (data.booking) {
        onBookingSynced(data.booking as BookingRecord);
      }
    } catch (err) {
      setErrorMessage(
        err instanceof Error
          ? err.message
          : "Something went wrong while contacting the service agent."
      );
    } finally {
      setIsLoading(false);
    }
  }

  async function sendMessage(text: string) {
    const trimmed = text.trim();
    if (!trimmed || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: trimmed,
      timestamp: new Date().toLocaleTimeString("en-ZA", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      }),
    };

    const nextHistory = [...messages, userMsg];
    setMessages(nextHistory);
    setInput("");
    await requestAgentReply(nextHistory);
  }

  function handleRetryLast() {
    if (isLoading) return;
    const hasUserMessage = messages.some((m) => m.role === "user");
    if (!hasUserMessage) return;
    void requestAgentReply(messages);
  }

  useEffect(() => {
    if (
      externalPrompt &&
      externalPrompt.id !== lastExternalPromptId.current
    ) {
      lastExternalPromptId.current = externalPrompt.id;
      void sendMessage(externalPrompt.text);
    }
  }, [externalPrompt]);

  function handleReset() {
    setMessages([INITIAL_MESSAGE]);
    setErrorMessage(null);
    localStorage.removeItem(STORAGE_KEY);
  }

  return (
    <div className="bg-white border border-[#DCE4DF] rounded-xl flex flex-col h-[560px] overflow-hidden">
      {/* Header */}
      <div className="px-5 py-4 border-b border-[#E7ECE9] flex items-center justify-between gap-4 bg-[#FCFDFC]">
        <div>
          <h2 className="text-base font-semibold text-[#111815]">
            Automated Service Concierge
          </h2>
          <p className="text-xs text-[#596861] mt-0.5">
            Instant answers · Rand quotes · Scheduling · Booking lookup
          </p>
        </div>
        <button
          type="button"
          onClick={handleReset}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#4B5953] hover:text-[#111815] hover:bg-[#F2F6F4] rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0"
          title="Start a fresh conversation"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          New Chat
        </button>
      </div>

      {/* Messages */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto px-5 py-4 space-y-4 bg-white"
      >
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${
              msg.role === "user" ? "items-end" : "items-start"
            }`}
          >
            <div
              className={`max-w-[88%] rounded-xl px-4 py-3 text-sm ${
                msg.role === "user"
                  ? "bg-[#14533C] text-white"
                  : "bg-[#F4F7F5] text-[#1F2B26] border border-[#E6ECE8]"
              }`}
            >
              {msg.role === "user" ? (
                <p className="leading-relaxed">{msg.content}</p>
              ) : (
                <div className="space-y-1">{renderFormattedText(msg.content)}</div>
              )}

              {msg.toolEvents && msg.toolEvents.length > 0 && (
                <div className="mt-3 pt-2.5 border-t border-[#DCE4DF] space-y-1">
                  {msg.toolEvents.map((ev, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-1.5 text-xs text-[#14533C] font-medium"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                      <span className="font-mono text-[11px]">{ev.summary}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <span className="text-[11px] text-[#6D7C75] mt-1 px-1 tabular-nums">
              {msg.role === "user" ? "You" : "EcoClean Agent"} · {msg.timestamp}
            </span>
          </div>
        ))}

        {isLoading && (
          <div className="flex flex-col items-start">
            <div className="bg-[#F4F7F5] border border-[#E6ECE8] rounded-xl px-4 py-3 text-sm text-[#596861]">
              Checking EcoClean knowledge base and availability...
            </div>
          </div>
        )}

        {errorMessage && (
          <div
            role="alert"
            className="flex items-start justify-between gap-3 p-3.5 rounded-lg bg-[#FDF2F2] border border-[#F3D1D1] text-xs text-[#8C1D1D]"
          >
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <p className="font-medium leading-relaxed">{errorMessage}</p>
            </div>
            <button
              type="button"
              onClick={handleRetryLast}
              className="px-2.5 py-1 text-xs font-medium bg-white border border-[#E5B8B8] hover:border-[#8C1D1D] text-[#8C1D1D] rounded-md transition-colors shrink-0 cursor-pointer"
            >
              Retry
            </button>
          </div>
        )}
      </div>

      {/* Quick Prompts */}
      <div className="px-4 py-2.5 border-t border-[#ECEFEF] bg-[#FAFBF9] flex items-center gap-2 overflow-x-auto">
        {QUICK_PROMPTS.map((prompt) => (
          <button
            key={prompt}
            type="button"
            disabled={isLoading}
            onClick={() => void sendMessage(prompt)}
            className="px-3 py-1.5 text-xs font-medium text-[#2E3D37] bg-white border border-[#DCE4DF] hover:border-[#14533C] hover:text-[#14533C] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Composer */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          void sendMessage(input);
        }}
        className="p-3 border-t border-[#E7ECE9] bg-white flex items-center gap-2"
      >
        <label htmlFor="agent-input" className="sr-only">
          Ask EcoClean Customer Service Agent
        </label>
        <input
          id="agent-input"
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about pricing in Rands, access, safety, or book a detail..."
          className="flex-1 h-10 px-3.5 text-sm bg-[#F8FAF8] border border-[#DCE4DF] rounded-lg text-[#111815] placeholder:text-[#73827B] focus:outline-none focus:border-[#14533C]"
        />
        <button
          type="submit"
          disabled={!input.trim() || isLoading}
          aria-label="Send message"
          className="h-10 px-4 inline-flex items-center justify-center gap-1.5 bg-[#14533C] hover:bg-[#0F402E] disabled:bg-[#9FB3AA] text-white text-sm font-medium rounded-lg transition-colors cursor-pointer shrink-0"
        >
          <span>Send</span>
          <ArrowUp className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}
