import { useEffect, useState } from "react";
import { Navbar } from "./components/Navbar";
import { AgentConcierge } from "./components/AgentConcierge";
import { ServicePackages } from "./components/ServicePackages";
import { OperationalChecklist } from "./components/OperationalChecklist";
import { KnowledgeBaseFaq } from "./components/KnowledgeBaseFaq";
import { BookingSection } from "./components/BookingSection";
import { ResilientImage } from "./components/ResilientImage";
import type {
  BookingRecord,
  ServiceTierId,
  VehicleSize,
} from "./data/ecoclean";

const FALLBACK_BOOKING: BookingRecord = {
  id: "EC-4812",
  customerName: "Thabo Mokoena",
  contact: "thabo.mokoena@example.co.za",
  location: "14 Oak Avenue, Bryanston, Johannesburg",
  vehicleDescription: "2024 Volkswagen Tiguan R-Line",
  vehicleSize: "suv",
  serviceTierId: "complete_eco",
  serviceTierName: "Complete Eco Detail",
  date: new Date().toISOString().slice(0, 10),
  timeWindow: "13:30",
  interiorAccessMethod: "Remote app unlock on technician arrival",
  paymentMethodPreference: "Mobile App Payment",
  estimatedDuration: "2 hrs 5 min",
  estimatedPrice: 1050,
  checklistStepCompleted: 2,
  status: "In Progress",
  createdAt: new Date().toISOString(),
};

export default function App() {
  const [bookings, setBookings] = useState<BookingRecord[]>([FALLBACK_BOOKING]);
  const [activeBookingId, setActiveBookingId] = useState<string>(
    FALLBACK_BOOKING.id
  );
  const [externalPrompt, setExternalPrompt] = useState<{
    id: number;
    text: string;
  } | null>(null);
  const [preselectedTier, setPreselectedTier] =
    useState<ServiceTierId>("complete_eco");
  const [preselectedSize, setPreselectedSize] = useState<VehicleSize>("sedan");

  useEffect(() => {
    fetch("/api/bookings")
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data.bookings) && data.bookings.length > 0) {
          setBookings(data.bookings);
          setActiveBookingId(data.bookings[0].id);
        }
      })
      .catch(() => {
        // Keep initial fallback booking if server is restarting
      });
  }, []);

  const activeBooking =
    bookings.find((b) => b.id === activeBookingId) ?? bookings[0];

  function handleAskAgent(prompt: string) {
    setExternalPrompt({ id: Date.now(), text: prompt });
    const el = document.getElementById("assistant");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  }

  function handleSelectTier(tierId: ServiceTierId, size: VehicleSize) {
    setPreselectedTier(tierId);
    setPreselectedSize(size);
    const el = document.getElementById("booking");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  }

  function handleBookingSynced(booking: BookingRecord) {
    setBookings((prev) => {
      const exists = prev.some((b) => b.id === booking.id);
      if (exists) {
        return prev.map((b) => (b.id === booking.id ? booking : b));
      }
      return [booking, ...prev];
    });
    setActiveBookingId(booking.id);
  }

  async function handleUpdateStep(bookingId: string, step: number) {
    const res = await fetch(`/api/bookings/${bookingId}/checklist`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ step }),
    });
    if (res.ok) {
      const data = await res.json();
      if (data.booking) {
        handleBookingSynced(data.booking as BookingRecord);
      }
    }
  }

  function scrollToBooking() {
    const el = document.getElementById("booking");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  }

  return (
    <div id="top" className="min-h-screen flex flex-col bg-[#F8FAF8] text-[#111815]">
      <Navbar onBookClick={scrollToBooking} />

      <main className="flex-1">
        {/* Hero & Automated Customer Service Agent Split */}
        <section id="assistant" className="py-12 md:py-16">
          <div className="max-w-[1200px] mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
              {/* Left Column: Proposition + Hero Visual */}
              <div className="lg:col-span-6 flex flex-col justify-between gap-6">
                <div>
                  <p className="text-xs font-medium text-[#14533C] tracking-wide mb-3">
                    EcoClean Mobile Car Detailing
                  </p>
                  <h1
                    style={{ fontSize: "clamp(2.25rem, 4vw, 3.35rem)" }}
                    className="font-semibold tracking-tight leading-[1.08] text-[#111815] text-balance"
                  >
                    Waterless detailing brought directly to your location.
                  </h1>
                  <p className="mt-4 text-base text-[#4B5953] leading-relaxed max-w-xl">
                    Ask our automated service concierge about vehicle access,
                    pet- and child-safe biodegradable formulas, accepted
                    payments, or book a 1 to 3 hour mobile appointment in
                    Rands.
                  </p>

                  <div className="mt-6 flex flex-wrap items-center gap-3">
                    <a
                      href="#booking"
                      className="px-5 py-2.5 text-sm font-medium text-white bg-[#14533C] hover:bg-[#0F402E] rounded-lg transition-colors whitespace-nowrap"
                    >
                      Book Detailing
                    </a>
                    <a
                      href="#services"
                      className="px-5 py-2.5 text-sm font-medium text-[#111815] bg-white border border-[#DCE4DF] hover:border-[#14533C] rounded-lg transition-colors whitespace-nowrap"
                    >
                      Compare Tiers
                    </a>
                  </div>
                </div>

                <div className="relative rounded-xl overflow-hidden border border-[#DCE4DF] aspect-video bg-[#1C2622]">
                  <ResilientImage
                    src="/src/assets/images/hero_waterless_detailing_1795174015986.jpg"
                    alt="EcoClean mobile technician performing waterless car detailing in a sunny driveway"
                    fallbackLabel="EcoClean Waterless Mobile Service"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent flex flex-col justify-end p-5">
                    <p className="text-xs text-[#D3E3DA]">
                      Driveway, complex, or office parkade · Zero water waste
                    </p>
                    <p className="text-sm font-medium text-white mt-0.5">
                      Self-contained mobile technicians equipped with
                      biodegradable plant-based cleansers.
                    </p>
                  </div>
                </div>
              </div>

              {/* Right Column: Dominant Interactive Agent */}
              <div className="lg:col-span-6 flex flex-col justify-between">
                <AgentConcierge
                  externalPrompt={externalPrompt}
                  onBookingSynced={handleBookingSynced}
                />
              </div>
            </div>

            {/* Full-Width 4-Column Service Standards Row */}
            <div className="mt-10 pt-8 border-t border-[#E2E8E4] grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div>
                <p className="text-xs text-[#596861]">Service Window</p>
                <p className="text-base font-semibold text-[#111815] mt-1 font-mono tabular-nums">
                  1 to 3 hours
                </p>
                <p className="text-xs text-[#596861] mt-1">
                  Tailored to vehicle size and condition.
                </p>
              </div>
              <div>
                <p className="text-xs text-[#596861]">Client Presence</p>
                <p className="text-base font-semibold text-[#111815] mt-1">
                  No need to be home
                </p>
                <p className="text-xs text-[#596861] mt-1">
                  Just leave unlocked if interior work is requested.
                </p>
              </div>
              <div>
                <p className="text-xs text-[#596861]">Formulation Safety</p>
                <p className="text-base font-semibold text-[#111815] mt-1">
                  Pets & children safe
                </p>
                <p className="text-xs text-[#596861] mt-1">
                  Exclusively non-toxic, biodegradable formulas.
                </p>
              </div>
              <div>
                <p className="text-xs text-[#596861]">Accepted Payments</p>
                <p className="text-base font-semibold text-[#111815] mt-1">
                  Card, EFT & Mobile App
                </p>
                <p className="text-xs text-[#596861] mt-1">
                  Processed on completion with digital receipt.
                </p>
              </div>
            </div>
          </div>
        </section>

        <ServicePackages
          onSelectTier={handleSelectTier}
          onAskAgent={handleAskAgent}
        />

        <OperationalChecklist
          activeBooking={activeBooking}
          bookings={bookings}
          onSelectBooking={(b) => setActiveBookingId(b.id)}
          onUpdateStep={handleUpdateStep}
        />

        <KnowledgeBaseFaq onAskAgent={handleAskAgent} />

        <BookingSection
          preselectedTier={preselectedTier}
          preselectedSize={preselectedSize}
          onBookingCreated={handleBookingSynced}
        />
      </main>

      <footer className="border-t border-[#E2E8E4] bg-[#F8FAF8] py-10">
        <div className="max-w-[1200px] mx-auto px-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <p className="font-display text-base font-semibold text-[#111815]">
              EcoClean Mobile Car Detailing
            </p>
            <p className="text-xs text-[#596861] mt-1">
              Waterless, non-toxic, biodegradable detailing brought directly to
              your location. Pricing in South African Rands (ZAR).
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-[#4B5953]">
            <a href="#assistant" className="hover:text-[#111815]">
              Service Agent
            </a>
            <a href="#services" className="hover:text-[#111815]">
              Detailing Tiers
            </a>
            <a href="#checklist" className="hover:text-[#111815]">
              Checklist
            </a>
            <a href="#faq" className="hover:text-[#111815]">
              Knowledge Base
            </a>
            <a href="#booking" className="hover:text-[#111815]">
              Book Detailing
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
